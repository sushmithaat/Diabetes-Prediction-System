from django.conf.global_settings import EMAIL_HOST_USER
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm

from .forms import CreateUserForm
from django.contrib import  messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from django.core.mail import send_mail,EmailMessage

def home(request):
    return render(request, 'home.html')

@login_required(login_url='login')
def predict(request):
    return render(request, 'predict.html')

@login_required(login_url='login')
def result(request):
    data = pd.read_csv(r"C:\DiabetesPredictionSystem\diabetes.csv")
    x = data.drop("Outcome", axis=1)
    y = data['Outcome']
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)
    model = LogisticRegression()
    model.fit(x_train, y_train)

    m = request.GET['email']
    name = request.GET['name']
    val1 = float(request.GET['n1'])
    val2 = float(request.GET['n2'])
    val3 = float(request.GET['n3'])
    val4 = float(request.GET['n4'])
    val5 = float(request.GET['n5'])
    val6 = float(request.GET['n6'])
    val7 = float(request.GET['n7'])
    val8 = float(request.GET['n8'])

    pred = model.predict([[val1, val2, val3, val4, val5, val6, val7, val8]])

    result1 = ""
    if pred == [1]:
        result1 = "Positive"
    else:
        result1 = "Negative"

    sub = "Diabetes Prediction Report"
    p1 = "Name : "+name
    p2 = "Result : "+result1
    res1 = (p1 + "<br>" + p2)

    email = EmailMessage(sub, res1, EMAIL_HOST_USER, [m])
    email.content_subtype = 'html'
    email.send()

    return render(request, 'result.html', {"result2": result1, "preg": val1, "glucose": val2, "bp": val3, "st": val4, "insulin": val5, "bmi": val6, "dpf": val7, "age": val8, "uname": name})


def loginPage(request):
    if request.user.is_authenticated:
        return redirect('main')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('main')
            else:
                messages.info(request, 'Username or Password is Incorrect')

        return render(request, 'login.html')

def logoutuser(request):
    logout(request)
    return redirect('login')

def register(request):
    if request.user.is_authenticated:
        return redirect('main')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, "Account was created for "+user)
                return redirect('login')

        context={'form': form}
        return render(request, 'register.html', context)

def about(request):
    return render(request, 'about.html')


def contact(request):
    return render(request, 'contact.html')

@login_required(login_url='login')
def main(request):
    return render(request, 'main.html')


